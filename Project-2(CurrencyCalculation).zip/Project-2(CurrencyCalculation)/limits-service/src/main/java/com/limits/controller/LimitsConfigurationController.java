package com.limits.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.limits.bean.LimitsConfiguration;
@RestController// it is used to create restful webservices using mvc 
@RequestMapping("limit")  //map http requests from mvc
public class LimitsConfigurationController {
	@Autowired
	LimitsConfiguration limits;

	@GetMapping("/getMaximum")
	public int getMaximum() {
		return limits.getMaximum();
	}

	@GetMapping("/getMinimum")
	public int getMinimum() {
		return limits.getMinimum();
	}

	@GetMapping("/getConfiguration")
	public LimitsConfiguration getConfiguration() {
		return limits;
	}
}
