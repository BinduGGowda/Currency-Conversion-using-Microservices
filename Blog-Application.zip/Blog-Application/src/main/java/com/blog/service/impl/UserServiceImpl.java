package com.blog.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.blog.entity.User;
import com.blog.payloads.UserDto;
import com.blog.repositories.UserRepo;
import com.blog.service.UserService;
public class UserServiceImpl implements UserService {
@Autowired
	private UserRepo userRepo;
	
@Override
	public UserDto CreateUser(UserDto userDto) {
	//Here, UserDto is passed whereas we need User Entity so i 
	//have create another method in the end
	
		User user=this.dtoToUser(userDto);
	    User SavedUser=this.userRepo.save(userDto);
        return this.userToDto(SavedUser);
	}

	@Override
	public UserDto UpdateUser(UserDto user, Integer UserId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UserDto getUserById(Integer userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<UserDto> getAllUsers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteUser(Integer userId) {
		// TODO Auto-generated method stub

	}
	private User dtoToUser(UserDto userDto) {
		//This method is used to convert userdto to user entity
			User user=new User();
			user.setId(userDto.getId());
			user.setName(userDto.getName());
			user.setEmail(userDto.getEmail());
			user.setPassword(userDto.getPassword());
			user.setAbout(userDto.getAbout());
			return user;
	}
	public UserDto userToDto(User user) {
		//this method is used to convert user entity to userDto
		UserDto userDto=new UserDto();
		userDto.setId(user.getId());
		userDto.setName(user.getName());
		userDto.setEmail(user.getEmail());
		userDto.setPassword(user.getPassword());
		userDto.setAbout(user.getAbout());
		return userDto;
		
		
	}
}
