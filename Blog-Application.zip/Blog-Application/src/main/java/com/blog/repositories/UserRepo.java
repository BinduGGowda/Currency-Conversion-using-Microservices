package com.blog.repositories;


import org.springframework.data.jpa.repository.JpaRepository;

import com.blog.entity.User;
import com.blog.payloads.UserDto;

public interface UserRepo extends JpaRepository<User,Integer>{

	User save(UserDto userDto);

}
